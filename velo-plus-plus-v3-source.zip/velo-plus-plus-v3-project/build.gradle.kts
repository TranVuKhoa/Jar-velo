plugins {
    alias(libs.plugins.fabric.loom)
}

base {
    archivesName = "velo-plus-plus-v3-1.21.11"
    version = libs.versions.mod.version.get()
    group = "com.velocitypp"
}

repositories {
    maven { url = uri("https://maven.meteordev.org/releases") }
    maven { url = uri("https://maven.meteordev.org/snapshots") }
}

dependencies {
    minecraft(libs.minecraft)
    mappings(variantOf(libs.yarn) { classifier("v2") })
    modImplementation(libs.fabric.loader)
    modImplementation(libs.meteor.client)
}

tasks.processResources {
    val propertyMap = mapOf(
        "version" to project.version,
        "mc_version" to libs.versions.minecraft.get()
    )
    inputs.properties(propertyMap)
    filteringCharset = "UTF-8"
    filesMatching("fabric.mod.json") { expand(propertyMap) }
}

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release = 21
}
