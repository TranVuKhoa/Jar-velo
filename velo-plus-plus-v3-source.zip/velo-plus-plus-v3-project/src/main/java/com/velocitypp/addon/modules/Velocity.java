package com.velocitypp.addon.modules;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import meteordevelopment.meteorclient.events.entity.player.PushEntityEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.CollisionShapeEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PistonBlock;
import net.minecraft.block.PistonExtensionBlock;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockEventS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;

public class Velocity extends Module {
    public enum Mode {
        Normal,
        Walls,
        Cancel,
        Grim,
        GrimV2,
        JumpReset,
        Reverse
    }

    private enum KnockbackSource {
        PLAYER,
        MOB,
        UNKNOWN
    }

    private enum ExplosionType {
        CRYSTAL,
        ANCHOR,
        OTHER
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgCombat = settings.createGroup("Combat KB");
    private final SettingGroup sgExplosion = settings.createGroup("Explosion KB");
    private final SettingGroup sgAntiPush = settings.createGroup("Anti Push");

    // ==================== GENERAL SETTINGS ====================
    public final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("The method used to achieve knockback modification.")
        .defaultValue(Mode.Normal)
        .build()
    );

    public final Setting<Double> horizontal = sgGeneral.add(new DoubleSetting.Builder()
        .name("horizontal")
        .description("Default horizontal knockback percentage.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(() -> mode.get() != Mode.Cancel && mode.get() != Mode.JumpReset)
        .build()
    );

    public final Setting<Double> vertical = sgGeneral.add(new DoubleSetting.Builder()
        .name("vertical")
        .description("Default vertical knockback percentage.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(() -> mode.get() != Mode.Cancel && mode.get() != Mode.JumpReset)
        .build()
    );

    public final Setting<Boolean> onlyOnGround = sgGeneral.add(new BoolSetting.Builder()
        .name("only-on-ground")
        .description("Only reduces knockback while on the ground.")
        .defaultValue(false)
        .visible(() -> mode.get() == Mode.Normal || mode.get() == Mode.Walls || mode.get() == Mode.Reverse)
        .build()
    );

    public final Setting<Boolean> explosions = sgGeneral.add(new BoolSetting.Builder()
        .name("explosions")
        .description("Modifies knockback received from explosions.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> pause = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-on-setback")
        .description("Pauses velocity briefly whenever you get rubberbanded/setback.")
        .defaultValue(true)
        .visible(() -> mode.get() == Mode.Cancel || mode.get() == Mode.Grim || mode.get() == Mode.GrimV2)
        .build()
    );

    public final Setting<Boolean> onlyPhased = sgGeneral.add(new BoolSetting.Builder()
        .name("only-phased")
        .description("Only reduces knockback while phased inside blocks.")
        .defaultValue(false)
        .visible(() -> mode.get() == Mode.Grim || mode.get() == Mode.GrimV2)
        .build()
    );

    public final Setting<Boolean> onlyCoveredHead = sgGeneral.add(new BoolSetting.Builder()
        .name("only-covered-head")
        .description("Only reduces knockback when a block is above your head.")
        .defaultValue(false)
        .visible(() -> mode.get() == Mode.Grim || mode.get() == Mode.GrimV2)
        .build()
    );

    public final Setting<Double> fallDistance = sgGeneral.add(new DoubleSetting.Builder()
        .name("fall-distance")
        .description("Pause velocity if falling from more than this distance in blocks (0 to disable).")
        .defaultValue(10.0)
        .min(0.0)
        .max(50.0)
        .sliderMax(50.0)
        .build()
    );

    public final Setting<Boolean> conceal = sgGeneral.add(new BoolSetting.Builder()
        .name("conceal")
        .description("Ignores fake 0-0-0 velocity packets sent after a setback.")
        .defaultValue(true)
        .build()
    );

    // ==================== COMBAT KB SETTINGS (PLAYER & MOB) ====================
    public final Setting<Boolean> antiPlayerKB = sgCombat.add(new BoolSetting.Builder()
        .name("anti-player-kb")
        .description("Resists knockback when hit by players.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Double> playerHorizontal = sgCombat.add(new DoubleSetting.Builder()
        .name("player-horizontal")
        .description("Horizontal knockback % when hit by a player.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(antiPlayerKB::get)
        .build()
    );

    public final Setting<Double> playerVertical = sgCombat.add(new DoubleSetting.Builder()
        .name("player-vertical")
        .description("Vertical knockback % when hit by a player.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(antiPlayerKB::get)
        .build()
    );

    public final Setting<Boolean> antiMobKB = sgCombat.add(new BoolSetting.Builder()
        .name("anti-mob-kb")
        .description("Resists knockback when hit by monsters/mobs.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Double> mobHorizontal = sgCombat.add(new DoubleSetting.Builder()
        .name("mob-horizontal")
        .description("Horizontal knockback % when hit by a mob.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(antiMobKB::get)
        .build()
    );

    public final Setting<Double> mobVertical = sgCombat.add(new DoubleSetting.Builder()
        .name("mob-vertical")
        .description("Vertical knockback % when hit by a mob.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(antiMobKB::get)
        .build()
    );

    // ==================== EXPLOSION KB SETTINGS (CRYSTAL & ANCHOR) ====================
    public final Setting<Boolean> antiCrystalKB = sgExplosion.add(new BoolSetting.Builder()
        .name("anti-crystal-kb")
        .description("Resists knockback from End Crystal explosions.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Double> crystalHorizontal = sgExplosion.add(new DoubleSetting.Builder()
        .name("crystal-horizontal")
        .description("Horizontal knockback % from End Crystal explosions.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(antiCrystalKB::get)
        .build()
    );

    public final Setting<Double> crystalVertical = sgExplosion.add(new DoubleSetting.Builder()
        .name("crystal-vertical")
        .description("Vertical knockback % from End Crystal explosions.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(antiCrystalKB::get)
        .build()
    );

    public final Setting<Boolean> antiAnchorKB = sgExplosion.add(new BoolSetting.Builder()
        .name("anti-anchor-kb")
        .description("Resists knockback from Respawn Anchor and Bed explosions.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Double> anchorHorizontal = sgExplosion.add(new DoubleSetting.Builder()
        .name("anchor-horizontal")
        .description("Horizontal knockback % from Respawn Anchor and Bed explosions.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(antiAnchorKB::get)
        .build()
    );

    public final Setting<Double> anchorVertical = sgExplosion.add(new DoubleSetting.Builder()
        .name("anchor-vertical")
        .description("Vertical knockback % from Respawn Anchor and Bed explosions.")
        .defaultValue(0.0)
        .min(0.0)
        .max(100.0)
        .sliderMax(100.0)
        .visible(antiAnchorKB::get)
        .build()
    );

    // ==================== ANTI PUSH SETTINGS (LIQUID, PISTON, BLOCK, ROD, ENTITY) ====================
    public final Setting<Boolean> antiPush = sgAntiPush.add(new BoolSetting.Builder()
        .name("anti-entity-push")
        .description("Prevents other entities from pushing you on collision.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> antiLiquidPush = sgAntiPush.add(new BoolSetting.Builder()
        .name("anti-liquid-push")
        .description("Prevents flowing water and lava from pushing you.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> activeLiquidCancel = sgAntiPush.add(new BoolSetting.Builder()
        .name("active-water-cancel")
        .description("Actively neutralizes water and lava current vectors every tick.")
        .defaultValue(true)
        .visible(antiLiquidPush::get)
        .build()
    );

    public final Setting<Boolean> antiBlockPush = sgAntiPush.add(new BoolSetting.Builder()
        .name("anti-block-push")
        .description("Prevents blocks from pushing you out when phased.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> antiPistonPush = sgAntiPush.add(new BoolSetting.Builder()
        .name("anti-piston-push")
        .description("Prevents pistons and moving blocks from pushing you.")
        .defaultValue(true)
        .build()
    );

    public final Setting<Boolean> antiFishingRod = sgAntiPush.add(new BoolSetting.Builder()
        .name("anti-fishing-rod")
        .description("Prevents fishing rods from pulling you.")
        .defaultValue(true)
        .build()
    );

    // ==================== INTERNAL STATE FIELDS ====================
    private boolean pendingJumpReset;
    private boolean concealNextZeroVelocity;
    private boolean sendGrimPacket;
    private int pistonImmunityTicks;
    private int lastAttackerId = -1;
    private long lastSetbackTimestamp = 0L;
    private long lastExplosionTimestamp = 0L;
    private ExplosionType lastExplosionType = ExplosionType.OTHER;

    private final Set<BlockPos> cachedAnchorsAndBeds = new HashSet<>();
    private final Set<Vec3d> cachedCrystalPositions = new HashSet<>();

    public Velocity() {
        this(Categories.Movement);
    }

    public Velocity(Category category) {
        super(category, "velo+++", "Knockback and entity push controls.");
    }

    @Override
    public void onActivate() {
        this.sendGrimPacket = false;
        this.concealNextZeroVelocity = false;
        this.pendingJumpReset = false;
        this.pistonImmunityTicks = 0;
        this.lastAttackerId = -1;
        this.cachedAnchorsAndBeds.clear();
        this.cachedCrystalPositions.clear();
    }

    @Override
    public void onDeactivate() {
        if (this.sendGrimPacket && isGrimMode()) {
            sendGrimBypassPacket();
        }
        this.sendGrimPacket = false;
        this.concealNextZeroVelocity = false;
        this.pendingJumpReset = false;
        this.pistonImmunityTicks = 0;
        this.cachedAnchorsAndBeds.clear();
        this.cachedCrystalPositions.clear();
    }

    // ==================== EVENT HANDLERS ====================

    @EventHandler
    private void onPushEntity(PushEntityEvent event) {
        if (this.antiPush.get() && event.pushed == mc.player) {
            event.cancel();
        }
    }

    @EventHandler
    private void onCollisionShape(CollisionShapeEvent event) {
        if (mc.player == null || mc.world == null) return;

        // Prevent moving piston extensions from pushing the player's bounding box
        if (this.antiPistonPush.get() && event.state != null) {
            if (event.state.isOf(Blocks.MOVING_PISTON)
                || event.state.isOf(Blocks.PISTON_HEAD)
                || event.state.getBlock() instanceof PistonExtensionBlock) {
                if (event.pos != null && mc.player.getBoundingBox().expand(0.5).intersects(new Box(event.pos))) {
                    event.shape = VoxelShapes.empty();
                }
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        // 1. Grim post-velocity packet
        if (this.sendGrimPacket && isGrimMode()) {
            sendGrimBypassPacket();
        }
        this.sendGrimPacket = false;
        this.concealNextZeroVelocity = false;

        // 2. JumpReset execution
        if (this.pendingJumpReset) {
            if (mc.player.isOnGround() && !mc.options.jumpKey.isPressed()) {
                mc.player.jump();
            }
            this.pendingJumpReset = false;
        }

        // 3. Cache nearby End Crystals & Respawn Anchors / Beds
        updateExplosionCaches();

        // 4. Anti Liquid Push (Flowing Water & Lava)
        if (this.antiLiquidPush.get() && this.activeLiquidCancel.get()) {
            handleAntiLiquidFlow();
        }

        // 5. Anti Piston Push & Anti Block Push
        if (this.antiPistonPush.get() || this.antiBlockPush.get()) {
            handleAntiPistonAndBlockPush();
        }

        // 6. Anti Fishing Rod
        if (this.antiFishingRod.get()) {
            handleAntiFishingRod();
        }
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        if (mc.player == null || mc.world == null) return;

        double maxFall = this.fallDistance.get();
        if (maxFall > 0.0 && mc.player.fallDistance >= (float) maxFall) {
            return;
        }

        // Setback detection for Pause & Conceal
        if (event.packet instanceof PlayerPositionLookS2CPacket) {
            this.lastSetbackTimestamp = System.currentTimeMillis();
            if (this.conceal.get()) {
                this.concealNextZeroVelocity = true;
            }
        }

        // Anti Fishing Rod status packet (status 31 = fishing hook pull)
        if (event.packet instanceof EntityStatusS2CPacket statusPacket && this.antiFishingRod.get()) {
            if (statusPacket.getStatus() == 31) {
                Entity entity = statusPacket.getEntity(mc.world);
                if (entity instanceof FishingBobberEntity hook && hook.getHookedEntity() == mc.player) {
                    event.cancel();
                    return;
                }
            }
        }

        // Anti Piston Push packet detection
        if (event.packet instanceof BlockEventS2CPacket blockEvent && this.antiPistonPush.get()) {
            if (blockEvent.getBlock() instanceof PistonBlock || blockEvent.getBlock() instanceof PistonExtensionBlock) {
                if (mc.player.getBlockPos().getSquaredDistance(blockEvent.getPos()) <= 16.0) {
                    this.pistonImmunityTicks = 6;
                }
            }
        }

        // Track attacker ID from damage packet (Player KB vs Mob KB)
        if (event.packet instanceof EntityDamageS2CPacket damagePacket) {
            if (damagePacket.entityId() == mc.player.getId()) {
                this.lastAttackerId = damagePacket.sourceCauseId();
            }
        }

        // Explosion KB (Crystal KB & Anchor/Bed KB)
        if (event.packet instanceof ExplosionS2CPacket explodePacket && this.explosions.get()) {
            handleExplosionPacket(event, explodePacket);
        }

        // Velocity Packet (Player KB, Mob KB, Rod Pull, Post-Explosion Motion)
        if (event.packet instanceof EntityVelocityUpdateS2CPacket motionPacket) {
            handleEntityMotionPacket(event, motionPacket);
        }
    }

    // ==================== CORE PROCESSING LOGIC ====================

    private void handleEntityMotionPacket(PacketEvent.Receive event, EntityVelocityUpdateS2CPacket packet) {
        if (packet.getEntityId() != mc.player.getId()) return;

        double packetVelX = packet.getVelocityX() / 8000.0;
        double packetVelY = packet.getVelocityY() / 8000.0;
        double packetVelZ = packet.getVelocityZ() / 8000.0;

        if (this.concealNextZeroVelocity) {
            if (packetVelX == 0.0 && packetVelY == 0.0 && packetVelZ == 0.0) {
                this.concealNextZeroVelocity = false;
                return;
            }
        }

        if (this.antiFishingRod.get() && isHookedByFishingRod()) {
            event.cancel();
            return;
        }

        if (this.antiPistonPush.get() && (this.pistonImmunityTicks > 0 || isNearMovingPiston())) {
            event.cancel();
            return;
        }

        long now = System.currentTimeMillis();
        double targetH = this.horizontal.get();
        double targetV = this.vertical.get();

        // Check if velocity packet was sent immediately by a Crystal or Anchor explosion
        if (now - this.lastExplosionTimestamp <= 60L) {
            if (this.lastExplosionType == ExplosionType.CRYSTAL) {
                if (!this.antiCrystalKB.get()) return;
                targetH = this.crystalHorizontal.get();
                targetV = this.crystalVertical.get();
            } else if (this.lastExplosionType == ExplosionType.ANCHOR) {
                if (!this.antiAnchorKB.get()) return;
                targetH = this.anchorHorizontal.get();
                targetV = this.anchorVertical.get();
            }
        } else {
            // Check if velocity packet was caused by Player or Mob
            KnockbackSource source = identifyKnockbackSource();
            if (source == KnockbackSource.PLAYER) {
                if (!this.antiPlayerKB.get()) return;
                targetH = this.playerHorizontal.get();
                targetV = this.playerVertical.get();
            } else if (source == KnockbackSource.MOB) {
                if (!this.antiMobKB.get()) return;
                targetH = this.mobHorizontal.get();
                targetV = this.mobVertical.get();
            }
        }

        switch (this.mode.get()) {
            case Normal -> {
                if (this.onlyOnGround.get() && !mc.player.isOnGround()) return;
                applyScaledMotion(event, packetVelX, packetVelY, packetVelZ, targetH, targetV, false);
            }
            case Walls -> {
                if (!isEntityPhased(mc.player) || (this.onlyOnGround.get() && !mc.player.isOnGround())) return;
                applyScaledMotion(event, packetVelX, packetVelY, packetVelZ, targetH, targetV, false);
            }
            case Cancel -> {
                if (shouldPauseForSetback()) return;
                event.cancel();
            }
            case Grim, GrimV2 -> {
                if (shouldPauseForSetback()) return;
                if (this.onlyPhased.get() && !isEntityPhased(mc.player)) return;
                if (this.onlyCoveredHead.get() && !isHeadCovered()) return;
                applyScaledMotion(event, packetVelX, packetVelY, packetVelZ, targetH, targetV, false);
                this.sendGrimPacket = true;
            }
            case JumpReset -> {
                this.pendingJumpReset = true;
                if (targetH < 100.0 || targetV < 100.0) {
                    applyScaledMotion(event, packetVelX, packetVelY, packetVelZ, targetH, targetV, false);
                }
            }
            case Reverse -> {
                if (this.onlyOnGround.get() && !mc.player.isOnGround()) return;
                applyScaledMotion(event, packetVelX, packetVelY, packetVelZ, targetH, targetV, true);
            }
        }
    }

    private void handleExplosionPacket(PacketEvent.Receive event, ExplosionS2CPacket packet) {
        Vec3d center = new Vec3d(packet.getX(), packet.getY(), packet.getZ());
        ExplosionType type = classifyExplosion(center);
        this.lastExplosionType = type;
        this.lastExplosionTimestamp = System.currentTimeMillis();

        double targetH = this.horizontal.get();
        double targetV = this.vertical.get();

        if (type == ExplosionType.CRYSTAL) {
            if (!this.antiCrystalKB.get()) return;
            targetH = this.crystalHorizontal.get();
            targetV = this.crystalVertical.get();
        } else if (type == ExplosionType.ANCHOR) {
            if (!this.antiAnchorKB.get()) return;
            targetH = this.anchorHorizontal.get();
            targetV = this.anchorVertical.get();
        }

        switch (this.mode.get()) {
            case Normal, JumpReset -> applyScaledExplosion(packet, targetH, targetV, false);
            case Reverse -> applyScaledExplosion(packet, targetH, targetV, true);
            case Walls -> {
                if (isEntityPhased(mc.player)) {
                    applyScaledExplosion(packet, targetH, targetV, false);
                }
            }
            case Cancel -> {
                if (shouldPauseForSetback()) return;
                if (targetH == 0.0 && targetV == 0.0) {
                    applyScaledExplosion(packet, 0.0, 0.0, false);
                } else {
                    applyScaledExplosion(packet, targetH, targetV, false);
                }
            }
            case Grim, GrimV2 -> {
                if (shouldPauseForSetback()) return;
                if (this.onlyPhased.get() && !isEntityPhased(mc.player)) return;
                if (this.onlyCoveredHead.get() && !isHeadCovered()) return;
                applyScaledExplosion(packet, targetH, targetV, false);
                this.sendGrimPacket = true;
            }
        }
    }

    private void applyScaledMotion(
        PacketEvent.Receive event,
        double packetVelX,
        double packetVelY,
        double packetVelZ,
        double horizPercent,
        double vertPercent,
        boolean reverse
    ) {
        event.cancel();
        if (horizPercent == 0.0 && vertPercent == 0.0 && !reverse) {
            return;
        }

        Vec3d currentVel = mc.player.getVelocity();
        double hScale = horizPercent / 100.0;
        double vScale = vertPercent / 100.0;

        if (reverse) {
            hScale = -Math.abs(hScale == 0.0 ? 0.5 : hScale);
        }

        double newX = currentVel.x + (packetVelX - currentVel.x) * hScale;
        double newY = currentVel.y + (packetVelY - currentVel.y) * vScale;
        double newZ = currentVel.z + (packetVelZ - currentVel.z) * hScale;

        mc.player.setVelocityClient(newX, newY, newZ);
    }

    private void applyScaledExplosion(
        ExplosionS2CPacket packet,
        double horizPercent,
        double vertPercent,
        boolean reverse
    ) {
        Optional<Vec3d> kbOpt = packet.getPlayerKnockback();
        if (kbOpt.isEmpty()) return;

        Vec3d kb = kbOpt.get();
        double hScale = horizPercent / 100.0;
        double vScale = vertPercent / 100.0;

        if (reverse) {
            hScale = -Math.abs(hScale == 0.0 ? 0.5 : hScale);
        }

        ((IVec3d) kb).meteor$set(kb.x * hScale, kb.y * vScale, kb.z * hScale);
    }

    private void handleAntiLiquidFlow() {
        if (mc.player.isTouchingWater() || mc.player.isInLava()) {
            Box box = mc.player.getBoundingBox().contract(0.001);
            int minX = MathHelper.floor(box.minX);
            int maxX = MathHelper.ceil(box.maxX);
            int minY = MathHelper.floor(box.minY);
            int maxY = MathHelper.ceil(box.maxY);
            int minZ = MathHelper.floor(box.minZ);
            int maxZ = MathHelper.ceil(box.maxZ);

            Vec3d flowPush = Vec3d.ZERO;
            int count = 0;

            for (int x = minX; x < maxX; x++) {
                for (int y = minY; y < maxY; y++) {
                    for (int z = minZ; z < maxZ; z++) {
                        BlockPos pos = new BlockPos(x, y, z);
                        FluidState fluidState = mc.world.getFluidState(pos);
                        if (fluidState.isIn(FluidTags.WATER) || fluidState.isIn(FluidTags.LAVA)) {
                            double fluidHeight = (float) y + fluidState.getHeight(mc.world, pos);
                            if (fluidHeight >= box.minY) {
                                Vec3d flow = fluidState.getVelocity(mc.world, pos);
                                if (flow.lengthSquared() > 0.0) {
                                    flowPush = flowPush.add(flow);
                                    count++;
                                }
                            }
                        }
                    }
                }
            }

            if (count > 0 && flowPush.lengthSquared() > 0.0) {
                Vec3d normalizedFlow = flowPush.normalize();
                double strength = mc.player.isInLava() ? 0.0023333333333333335 : 0.014;
                Vec3d currentMotion = mc.player.getVelocity();
                double counterX = currentMotion.x - normalizedFlow.x * strength;
                double counterZ = currentMotion.z - normalizedFlow.z * strength;

                if (mc.player.input.movementForward == 0.0F && mc.player.input.movementSideways == 0.0F) {
                    counterX = 0.0;
                    counterZ = 0.0;
                }
                mc.player.setVelocity(counterX, currentMotion.y, counterZ);
            }
        }
    }

    private void handleAntiPistonAndBlockPush() {
        if (this.pistonImmunityTicks > 0) {
            this.pistonImmunityTicks--;
        }

        if (this.antiPistonPush.get() && isNearMovingPiston()) {
            Vec3d vel = mc.player.getVelocity();
            if (mc.player.input.movementForward == 0.0F && mc.player.input.movementSideways == 0.0F) {
                mc.player.setVelocity(0.0, Math.min(vel.y, 0.0), 0.0);
            }
        }

        if (this.antiBlockPush.get() && isEntityPhased(mc.player)) {
            mc.player.noClip = false;
            if (mc.player.input.movementForward == 0.0F && mc.player.input.movementSideways == 0.0F) {
                Vec3d vel = mc.player.getVelocity();
                mc.player.setVelocity(0.0, vel.y, 0.0);
            }
        }
    }

    private void handleAntiFishingRod() {
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof FishingBobberEntity hook && hook.getHookedEntity() == mc.player) {
                hook.setVelocity(Vec3d.ZERO);
            }
        }
    }

    private boolean isHookedByFishingRod() {
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof FishingBobberEntity hook && hook.getHookedEntity() == mc.player) {
                return true;
            }
        }
        return false;
    }

    private boolean isNearMovingPiston() {
        Box expanded = mc.player.getBoundingBox().expand(0.6);
        int minX = MathHelper.floor(expanded.minX);
        int maxX = MathHelper.ceil(expanded.maxX);
        int minY = MathHelper.floor(expanded.minY);
        int maxY = MathHelper.ceil(expanded.maxY);
        int minZ = MathHelper.floor(expanded.minZ);
        int maxZ = MathHelper.ceil(expanded.maxZ);

        for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
                for (int z = minZ; z < maxZ; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    BlockState state = mc.world.getBlockState(pos);
                    if (state.isOf(Blocks.MOVING_PISTON)
                        || state.isOf(Blocks.PISTON_HEAD)
                        || state.getBlock() instanceof PistonExtensionBlock) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void updateExplosionCaches() {
        this.cachedCrystalPositions.clear();
        this.cachedAnchorsAndBeds.clear();

        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof EndCrystalEntity && entity.squaredDistanceTo(mc.player) <= 169.0) {
                this.cachedCrystalPositions.add(entity.getPos());
            }
        }

        BlockPos playerPos = mc.player.getBlockPos();
        for (int dx = -6; dx <= 6; dx++) {
            for (int dy = -6; dy <= 6; dy++) {
                for (int dz = -6; dz <= 6; dz++) {
                    BlockPos checkPos = playerPos.add(dx, dy, dz);
                    BlockState state = mc.world.getBlockState(checkPos);
                    if (state.getBlock() instanceof RespawnAnchorBlock || state.getBlock() instanceof BedBlock) {
                        this.cachedAnchorsAndBeds.add(checkPos.toImmutable());
                    }
                }
            }
        }
    }

    private ExplosionType classifyExplosion(Vec3d explosionCenter) {
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof EndCrystalEntity && entity.getPos().squaredDistanceTo(explosionCenter) <= 6.25) {
                return ExplosionType.CRYSTAL;
            }
        }
        for (Vec3d crystalPos : this.cachedCrystalPositions) {
            if (crystalPos.squaredDistanceTo(explosionCenter) <= 6.25) {
                return ExplosionType.CRYSTAL;
            }
        }

        BlockPos centerBlock = BlockPos.ofFloored(explosionCenter);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos pos = centerBlock.add(dx, dy, dz);
                    BlockState state = mc.world.getBlockState(pos);
                    if (state.getBlock() instanceof RespawnAnchorBlock
                        || state.getBlock() instanceof BedBlock
                        || this.cachedAnchorsAndBeds.contains(pos)) {
                        return ExplosionType.ANCHOR;
                    }
                }
            }
        }

        return ExplosionType.OTHER;
    }

    private KnockbackSource identifyKnockbackSource() {
        if (this.lastAttackerId != -1) {
            Entity attacker = mc.world.getEntityById(this.lastAttackerId);
            this.lastAttackerId = -1;
            if (attacker instanceof PlayerEntity) {
                return KnockbackSource.PLAYER;
            }
            if (attacker instanceof MobEntity) {
                return KnockbackSource.MOB;
            }
            if (attacker instanceof ProjectileEntity projectile && projectile.getOwner() != null) {
                if (projectile.getOwner() instanceof PlayerEntity) {
                    return KnockbackSource.PLAYER;
                }
                if (projectile.getOwner() instanceof MobEntity) {
                    return KnockbackSource.MOB;
                }
            }
        }

        Entity lastHurtBy = mc.player.getAttacker();
        if (lastHurtBy instanceof PlayerEntity) {
            return KnockbackSource.PLAYER;
        }
        if (lastHurtBy instanceof MobEntity) {
            return KnockbackSource.MOB;
        }

        PlayerEntity closestPlayer = null;
        MobEntity closestMob = null;
        double minPlayerDist = 36.0;
        double minMobDist = 36.0;

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player || !entity.isAlive()) continue;
            double dist = entity.squaredDistanceTo(mc.player);
            if (entity instanceof PlayerEntity p && dist < minPlayerDist) {
                minPlayerDist = dist;
                closestPlayer = p;
            } else if (entity instanceof MobEntity m && dist < minMobDist) {
                minMobDist = dist;
                closestMob = m;
            }
        }

        if (closestPlayer != null && minPlayerDist <= minMobDist) {
            return KnockbackSource.PLAYER;
        }
        if (closestMob != null) {
            return KnockbackSource.MOB;
        }
        return KnockbackSource.UNKNOWN;
    }

    private boolean shouldPauseForSetback() {
        if (this.pause.get()) {
            return System.currentTimeMillis() - this.lastSetbackTimestamp < 100L;
        }
        return false;
    }

    private boolean isHeadCovered() {
        BlockPos headAbove = mc.player.isCrawling()
            ? mc.player.getBlockPos().up(1)
            : mc.player.getBlockPos().up(2);
        return !mc.world.getBlockState(headAbove).isAir();
    }

    private boolean isGrimMode() {
        Mode m = this.mode.get();
        return m == Mode.Grim || m == Mode.GrimV2;
    }

    private void sendGrimBypassPacket() {
        float yaw = Rotations.serverYaw;
        float pitch = Rotations.serverPitch;
        float jitter = (float) ((Math.random() * 2.0 - 1.0) * 0.001F);
        float clampedPitch = MathHelper.clamp(pitch + jitter, -90.0F, 90.0F);

        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ(),
                yaw,
                clampedPitch,
                mc.player.isOnGround(),
                mc.player.horizontalCollision
            ));
        }
    }

    private boolean isEntityPhased(Entity entity) {
        if (entity == null || mc.world == null) return false;

        Box box = entity.getBoundingBox();
        int minX = MathHelper.floor(box.minX);
        int maxX = MathHelper.ceil(box.maxX);
        int minY = MathHelper.floor(box.minY);
        int maxY = MathHelper.ceil(box.maxY);
        int minZ = MathHelper.floor(box.minZ);
        int maxZ = MathHelper.ceil(box.maxZ);

        for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
                for (int z = minZ; z < maxZ; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    BlockState state = mc.world.getBlockState(pos);
                    VoxelShape shape = state.getCollisionShape(mc.world, pos);
                    if (!shape.isEmpty() && shape.getBoundingBox().offset(pos).intersects(box)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public String getInfoString() {
        Mode currentMode = this.mode.get();
        if (currentMode == Mode.Cancel) {
            return "0%, 0%";
        }
        if (currentMode == Mode.Grim || currentMode == Mode.GrimV2 || currentMode == Mode.JumpReset || currentMode == Mode.Reverse) {
            return currentMode.name();
        }
        return this.horizontal.get().intValue() + "%, " + this.vertical.get().intValue() + "%";
    }
}
