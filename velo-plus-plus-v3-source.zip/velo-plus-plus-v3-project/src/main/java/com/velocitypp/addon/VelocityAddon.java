package com.velocitypp.addon;

import com.velocitypp.addon.modules.Velocity;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class VelocityAddon extends MeteorAddon {
    public static final Category VELO_CATEGORY = new Category("Velo+++");

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(VELO_CATEGORY);
    }

    @Override
    public void onInitialize() {
        Modules.get().add(new Velocity(VELO_CATEGORY));
    }

    @Override
    public String getPackage() {
        return "com.velocitypp.addon";
    }
}
