# Velo+++ — Meteor Addon for Minecraft 1.21.11

This project repackages the supplied V3 source as a standalone Meteor addon. The module is registered under its own ClickGUI category, `Velo+++`, and its module name is `velo+++`.

## Source layout

- `com.velocitypp.addon.VelocityAddon`: Meteor addon entrypoint and custom category registration.
- `com.velocitypp.addon.modules.Velocity`: V3 module event handlers and settings.
- `fabric.mod.json`: points the `meteor` entrypoint at `VelocityAddon`.

## Build requirements

- JDK 21
- Gradle 9.2.0
- Network access to Fabric Maven, Meteor Maven and Gradle distribution services

Build with:

```sh
gradle build
```

The JAR will be placed in `build/libs/`.

A GitHub Actions workflow is included. After placing this project in a GitHub repository, run the `Build Velo+++` workflow and download the generated artifact.

## Important verification note

This source package has been structurally prepared, but it has **not** been compiled against the real Meteor 1.21.11 dependency in the current environment. The build machine could not resolve external hosts for Gradle and Meteor Maven, so no runnable JAR is included. A successful remote build is still required before installing it in the game.
